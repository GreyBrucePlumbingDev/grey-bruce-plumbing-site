// Type definitions for font files
declare module "*.woff2" {
    const content: string
    export default content
  }
  
  declare module "*.woff" {
    const content: string
    export default content
  }
  
  declare module "*.ttf" {
    const content: string
    export default content
  }
  
  