"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useCallback } from "react"
import { v4 as uuidv4 } from "uuid"
import { DialogflowService } from "../services/dialogflow-service"
import { ChatbotService } from "../services/chatbot-service"
import type { ChatMessage, DialogflowContext, ConversationState } from "../types"

interface ChatbotContextType {
  messages: ChatMessage[]
  isOpen: boolean
  isLoading: boolean
  conversationState: ConversationState
  sendMessage: (text: string) => Promise<void>
  toggleChatbot: () => void
  resetConversation: () => void
  initiateHumanHandoff: () => Promise<void>
  minimizeChatbot: () => void
}

const ChatbotContext = createContext<ChatbotContextType | undefined>(undefined)

export const ChatbotProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [isOpen, setIsOpen] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [sessionId, setSessionId] = useState("")
  const [conversationState, setConversationState] = useState<ConversationState>("initial")
  const [contexts, setContexts] = useState<DialogflowContext[]>([])
  const [companyInfo, setCompanyInfo] = useState<any>(null)

  // Fetch company information on initial load
  useEffect(() => {
    const fetchCompanyInfo = async () => {
      try {
        const info = await ChatbotService.getCompanyInfo()
        setCompanyInfo(info)
      } catch (error) {
        console.error("Error fetching company info:", error)
      }
    }

    fetchCompanyInfo()
  }, [])

  // Initialize session ID and welcome message
  useEffect(() => {
    const newSessionId = uuidv4()
    setSessionId(newSessionId)

    // Send welcome event when chatbot is first opened
    const handleWelcome = async () => {
      if (isOpen) {
        setIsLoading(true)
        try {
          const response = await DialogflowService.sendEvent("WELCOME", newSessionId)

          // Update conversation state
          if (response.conversationState) {
            setConversationState(response.conversationState)
          }

          // Update contexts
          if (response.outputContexts) {
            setContexts(response.outputContexts)
          }

          // Process the response with our service to enhance it with Supabase data
          const enhancedText = await ChatbotService.processResponse(response)

          // Add bot message
          const botMessage: ChatMessage = {
            id: uuidv4(),
            text: enhancedText,
            sender: "bot",
            timestamp: new Date(),
            state: response.conversationState,
            contexts: response.outputContexts,
          }

          setMessages([botMessage])
        } catch (error) {
          console.error("Error sending welcome event:", error)

          // Add fallback message
          const fallbackMessage: ChatMessage = {
            id: uuidv4(),
            text: "Welcome to Grey-Bruce Plumbing! How can I help you today?",
            sender: "bot",
            timestamp: new Date(),
            state: "initial",
          }

          setMessages([fallbackMessage])
        } finally {
          setIsLoading(false)
        }
      }
    }

    handleWelcome()
  }, [isOpen])

  // Send message to Dialogflow
  const sendMessage = useCallback(
    async (text: string) => {
      if (!text.trim()) return

      // Add user message
      const userMessage: ChatMessage = {
        id: uuidv4(),
        text,
        sender: "user",
        timestamp: new Date(),
        state: conversationState,
        contexts,
      }

      setMessages((prev) => [...prev, userMessage])
      setIsLoading(true)

      try {
        // Send message to Dialogflow with current contexts
        const response = await DialogflowService.sendMessage(text, sessionId, contexts)

        // Update conversation state
        if (response.conversationState) {
          setConversationState(response.conversationState)
        }

        // Update contexts
        if (response.outputContexts) {
          setContexts(response.outputContexts)
        }

        // Process the response with our service to enhance it with Supabase data
        const enhancedText = await ChatbotService.processResponse(response)

        // Add bot message
        const botMessage: ChatMessage = {
          id: uuidv4(),
          text: enhancedText,
          sender: "bot",
          timestamp: new Date(),
          state: response.conversationState,
          contexts: response.outputContexts,
        }

        setMessages((prev) => [...prev, botMessage])

        // Check if we need to transition to human handoff
        if (response.conversationState === "human_handoff") {
          console.log("Transitioning to human handoff")
        }
      } catch (error) {
        console.error("Error sending message:", error)

        // Add error message
        const errorMessage: ChatMessage = {
          id: uuidv4(),
          text: "I'm having trouble connecting right now. Please try again or call our office directly.",
          sender: "bot",
          timestamp: new Date(),
          state: conversationState,
        }

        setMessages((prev) => [...prev, errorMessage])
      } finally {
        setIsLoading(false)
      }
    },
    [sessionId, conversationState, contexts],
  )

  // Toggle chatbot open/closed
  const toggleChatbot = useCallback(() => {
    setIsOpen((prev) => {
      // If we're opening the chatbot and there are no messages, we'll need to show the welcome message
      if (!prev && messages.length === 0) {
        // We'll handle the welcome message in the useEffect that watches isOpen
      }
      return !prev
    })
  }, [messages.length])

  // Reset conversation
  const resetConversation = useCallback(() => {
    const newSessionId = uuidv4()
    setSessionId(newSessionId)
    setMessages([])
    setConversationState("initial")
    setContexts([])

    // Send welcome event
    const handleWelcome = async () => {
      setIsLoading(true)
      try {
        const response = await DialogflowService.sendEvent("WELCOME", newSessionId)

        // Update conversation state
        if (response.conversationState) {
          setConversationState(response.conversationState)
        }

        // Update contexts
        if (response.outputContexts) {
          setContexts(response.outputContexts)
        }

        // Process the response with our service to enhance it with Supabase data
        const enhancedText = await ChatbotService.processResponse(response)

        // Add bot message
        const botMessage: ChatMessage = {
          id: uuidv4(),
          text: enhancedText,
          sender: "bot",
          timestamp: new Date(),
          state: response.conversationState,
          contexts: response.outputContexts,
        }

        setMessages([botMessage])
      } catch (error) {
        console.error("Error sending welcome event:", error)

        // Add fallback message
        const fallbackMessage: ChatMessage = {
          id: uuidv4(),
          text: "Welcome to Grey-Bruce Plumbing! How can I help you today?",
          sender: "bot",
          timestamp: new Date(),
          state: "initial",
        }

        setMessages([fallbackMessage])
      } finally {
        setIsLoading(false)
      }
    }

    handleWelcome()
  }, [])

  // Initiate human handoff
  const initiateHumanHandoff = useCallback(async () => {
    setIsLoading(true)
    try {
      // Send human handoff event
      const response = await DialogflowService.sendEvent("HUMAN_HANDOFF", sessionId)

      // Update conversation state
      if (response.conversationState) {
        setConversationState(response.conversationState)
      }

      // Update contexts
      if (response.outputContexts) {
        setContexts(response.outputContexts)
      }

      // Get company info for contact details
      const companyInfo = await ChatbotService.getCompanyInfo()

      // Create enhanced response with contact information
      let enhancedText = response.fulfillmentText
      if (companyInfo) {
        enhancedText = `${response.fulfillmentText}\n\nYou can reach us at ${companyInfo.phone_number} during business hours or ${companyInfo.emergency_phone} for emergencies.`
      }

      // Add bot message
      const botMessage: ChatMessage = {
        id: uuidv4(),
        text: enhancedText,
        sender: "bot",
        timestamp: new Date(),
        state: response.conversationState,
        contexts: response.outputContexts,
      }

      setMessages((prev) => [...prev, botMessage])
    } catch (error) {
      console.error("Error initiating human handoff:", error)

      // Add error message
      const errorMessage: ChatMessage = {
        id: uuidv4(),
        text: "I'm having trouble connecting you with our team. Please call our office directly.",
        sender: "bot",
        timestamp: new Date(),
        state: "human_handoff",
      }

      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }, [sessionId])

  // Find the minimizeChatbot function and update it
  const minimizeChatbot = useCallback(() => {
    setIsOpen(false)
  }, [])

  return (
    <ChatbotContext.Provider
      value={{
        messages,
        isOpen,
        isLoading,
        conversationState,
        sendMessage,
        toggleChatbot,
        resetConversation,
        initiateHumanHandoff,
        minimizeChatbot,
      }}
    >
      {children}
    </ChatbotContext.Provider>
  )
}

export const useChatbot = () => {
  const context = useContext(ChatbotContext)
  if (context === undefined) {
    throw new Error("useChatbot must be used within a ChatbotProvider")
  }
  return context
}

