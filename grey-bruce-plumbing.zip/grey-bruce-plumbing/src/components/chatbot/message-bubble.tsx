"use client"

import type React from "react"
import type { ChatMessage, ConversationState } from "../../types"
import { useSitewideSettings } from "../../hooks/useSitewideSettings"

interface MessageBubbleProps {
  message: ChatMessage
  state?: ConversationState
}

export const MessageBubble: React.FC<MessageBubbleProps> = ({ message, state }) => {
  const { settings } = useSitewideSettings()
  const isUser = message.sender === "user"

  // Get state indicator color
  const getStateColor = (state?: ConversationState) => {
    switch (state) {
      case "initial":
        return "bg-blue-200"
      case "gathering_info":
        return "bg-yellow-200"
      case "suggesting":
        return "bg-green-200"
      case "human_handoff":
        return "bg-red-200"
      default:
        return "bg-gray-200"
    }
  }

  // Format message text with links and line breaks
  const formatMessageText = (text: string) => {
    // Replace URLs with clickable links
    const urlRegex = /(https?:\/\/[^\s]+)/g
    const textWithLinks = text.replace(
      urlRegex,
      (url) => `<a href="${url}" target="_blank" rel="noopener noreferrer" class="text-[#7ac144] underline">${url}</a>`,
    )

    // Replace phone numbers with clickable links
    const phoneRegex = /($$\d{3}$$\s*\d{3}-\d{4}|\d{3}-\d{3}-\d{4})/g
    let textWithPhoneLinks = textWithLinks.replace(
      phoneRegex,
      (phone) => `<a href="tel:${phone.replace(/[()-\s]/g, "")}" class="text-[#7ac144] underline">${phone}</a>`,
    )

    // Replace booking link placeholder with actual link if available
    if (settings?.booking_link) {
      const textWithPhoneLinksReplaced = textWithPhoneLinks.replace(
        /\[booking\]/g,
        `<a href="${settings.booking_link}" target="_blank" rel="noopener noreferrer" class="text-[#7ac144] underline">book online</a>`,
      )
      textWithPhoneLinks = textWithPhoneLinksReplaced
    }

    // Replace line breaks with <br> tags
    return textWithPhoneLinks.replace(/\n/g, "<br>")
  }

  // Dynamic classes for message bubble
  const messageBubbleClasses = [
    "max-w-[80%]",
    "rounded-lg",
    "px-4",
    "py-2",
    isUser ? "bg-[#152f59] text-white" : "bg-gray-100 text-black",
  ].join(" ")

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={messageBubbleClasses}>
        {/* State indicator (only for bot messages) */}
        {!isUser && state && (
          <div className="flex items-center mb-1">
            <div className={`w-2 h-2 rounded-full mr-2 ${getStateColor(state)}`} />
            <span className="text-xs text-gray-500 capitalize">{state.replace("_", " ")}</span>
          </div>
        )}

        {/* Message text with formatted content */}
        {isUser ? (
          <div className="whitespace-pre-wrap">{message.text}</div>
        ) : (
          <div className="whitespace-pre-wrap" dangerouslySetInnerHTML={{ __html: formatMessageText(message.text) }} />
        )}

        {/* Timestamp */}
        <div className="text-xs opacity-70 mt-1 text-right">
          {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </div>
      </div>
    </div>
  )
}

