"use client"

// Update the ChatInterface component to handle service recommendations

import type React from "react"
import { useState, useRef, useEffect } from "react"
import { useChatbot } from "../../contexts/chatbot-context"
import { MessageBubble } from "./message-bubble"
import { useSitewideSettings } from "../../hooks/useSitewideSettings"
import type { SitewideSettings } from "../../types/SitewideSettings"

export const ChatInterface: React.FC = () => {
  const { messages, isLoading, conversationState, sendMessage, resetConversation, initiateHumanHandoff } = useChatbot()
  const { settings } = useSitewideSettings() as { settings: SitewideSettings | null; loading: boolean }

  const [input, setInput] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Update the form submission handler to prevent default behavior properly
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim() && !isLoading) {
      sendMessage(input)
      setInput("")
    }
  }

  // Make sure the input field has proper focus management
  useEffect(() => {
    // Add a small delay to ensure the DOM is ready
    const timer = setTimeout(() => {
      const inputElement = document.querySelector(".chatbot-input") as HTMLInputElement
      if (inputElement && !isLoading && conversationState !== "human_handoff") {
        inputElement.focus()
      }
    }, 100)

    return () => clearTimeout(timer)
  }, [isLoading, conversationState])

  // Render quick reply buttons based on conversation state
  const renderQuickReplies = () => {
    const buttonClasses = "btn btn-xs btn-outline text-[#152f59] border-[#152f59] hover:bg-[#152f59] hover:text-white"

    switch (conversationState) {
      case "initial":
        return (
          <div className="flex flex-wrap gap-2 mt-2">
            <button className={buttonClasses} onClick={() => sendMessage("I have a plumbing issue")}>
              I have a plumbing issue
            </button>
            <button className={buttonClasses} onClick={() => sendMessage("What services do you offer?")}>
              What services do you offer?
            </button>
            <button className={buttonClasses} onClick={() => sendMessage("What areas do you serve?")}>
              Service areas
            </button>
            <button className={buttonClasses} onClick={() => sendMessage("What are your business hours?")}>
              Business hours
            </button>
          </div>
        )

      case "gathering_info":
        return (
          <div className="flex flex-wrap gap-2 mt-2">
            <button className={buttonClasses} onClick={() => sendMessage("It's an emergency")}>
              It's an emergency
            </button>
            <button className={buttonClasses} onClick={() => sendMessage("It just started today")}>
              It just started today
            </button>
            <button className={buttonClasses} onClick={() => initiateHumanHandoff()}>
              Talk to a human
            </button>
          </div>
        )

      case "suggesting":
        return (
          <div className="flex flex-wrap gap-2 mt-2">
            <button className={buttonClasses} onClick={() => sendMessage("Tell me more about this service")}>
              Tell me more
            </button>
            <button className={buttonClasses} onClick={() => window.open(settings?.booking_link || "#", "_blank")}>
              Book now
            </button>
            <button className={buttonClasses} onClick={() => initiateHumanHandoff()}>
              Contact your team
            </button>
          </div>
        )

      case "human_handoff":
        return (
          <div className="flex flex-wrap gap-2 mt-2">
            <button
              className={buttonClasses}
              onClick={() => (window.location.href = `tel:${settings?.emergency_phone || "+1234567890"}`)}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-4 w-4 mr-1 inline"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                />
              </svg>
              Call Now
            </button>
            <button className={buttonClasses} onClick={() => window.open(settings?.booking_link || "#", "_blank")}>
              Book Online
            </button>
            <button className={buttonClasses} onClick={() => resetConversation()}>
              Start New Chat
            </button>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} state={message.state} />
        ))}
        {isLoading && (
          <div className="flex justify-center items-center py-2">
            <span className="loading loading-spinner loading-md text-[#152f59]"></span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick reply buttons */}
      <div className="px-4 mb-2">{renderQuickReplies()}</div>

      {/* Input form */}
      <form onSubmit={handleSubmit} className="border-t p-4 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your message..."
          disabled={isLoading || conversationState === "human_handoff"}
          className="input input-bordered w-full focus:outline-[#7ac144] chatbot-input"
        />
        <button
          type="submit"
          disabled={!input.trim() || isLoading || conversationState === "human_handoff"}
          className="btn btn-square bg-[#152f59] hover:bg-[#152f59]/90 text-white disabled:bg-gray-300"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path
              fillRule="evenodd"
              d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 1.414L10.586 9H7a1 1 0 100 2h3.586l-1.293 1.293a1 1 0 101.414 1.414l3-3a1 1 0 000-1.414z"
              clipRule="evenodd"
            />
          </svg>
        </button>
        <button
          type="button"
          onClick={resetConversation}
          className="btn btn-square btn-outline border-[#152f59] text-[#152f59] hover:bg-[#152f59] hover:text-white"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
            <path
              fillRule="evenodd"
              d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z"
              clipRule="evenodd"
            />
          </svg>
        </button>
      </form>
    </div>
  )
}

