import { supabase } from "../lib/supabase"
import type { SitewideSettings, PlumbingIssue, ServiceRecommendation, DialogflowResponse } from "../types"

/**
 * Service for handling chatbot data retrieval and processing
 */
export const ChatbotService = {
  /**
   * Fetches company information from Supabase
   */
  async getCompanyInfo(): Promise<SitewideSettings | null> {
    try {
      const { data, error } = await supabase.from("sitewide_settings").select("*").single()

      if (error) throw error
      return data
    } catch (error) {
      console.error("Error fetching company info:", error)
      return null
    }
  },

  /**
   * Fetches service areas from Supabase
   */
  async getServiceAreas(): Promise<string[]> {
    try {
      const { data, error } = await supabase.from("service_areas").select("name").eq("is_main_address", false)

      if (error) throw error
      return data.map((area) => area.name)
    } catch (error) {
      console.error("Error fetching service areas:", error)
      return []
    }
  },

  /**
   * Evaluates a plumbing issue and returns severity and recommendations
   */
  async evaluatePlumbingIssue(description: string): Promise<PlumbingIssue | null> {
    try {
      // First, check for emergency keywords
      const emergencyKeywords = ["burst", "flooding", "flood", "sewage", "backup", "gas", "leak", "emergency"]
      const isEmergency = emergencyKeywords.some((keyword) => description.toLowerCase().includes(keyword))

      // Query the plumbing_issues table to find matching issues
      const { data, error } = await supabase.from("plumbing_issues").select("*")

      if (error) throw error

      if (!data || data.length === 0) {
        // Fallback if no issues found in database
        return isEmergency
          ? {
              id: "emergency",
              name: "Emergency Plumbing",
              description: "This appears to be an emergency situation.",
              severity: "high",
              recommendedService: "emergency-plumbing",
              emergencyContact: true,
            }
          : null
      }

      // Find the most relevant issue by matching keywords
      const relevantIssues = data.filter((issue) => {
        const keywords = issue.keywords.split(",").map((k: string) => k.trim().toLowerCase())
        return keywords.some((keyword) => description.toLowerCase().includes(keyword))
      })

      // If emergency was detected, prioritize high severity issues
      if (isEmergency) {
        const emergencyIssue = relevantIssues.find((issue) => issue.severity === "high") || relevantIssues[0]
        if (emergencyIssue) {
          return {
            ...emergencyIssue,
            emergencyContact: true,
          }
        }
      }

      // Return the most relevant issue or null if none found
      return relevantIssues.length > 0 ? relevantIssues[0] : null
    } catch (error) {
      console.error("Error evaluating plumbing issue:", error)
      return null
    }
  },

  /**
   * Gets service recommendation based on issue
   */
  async getServiceRecommendation(serviceSlug: string): Promise<ServiceRecommendation | null> {
    try {
      const { data, error } = await supabase
        .from("services")
        .select("id, title, summary, slug")
        .eq("slug", serviceSlug)
        .single()

      if (error) throw error

      if (!data) return null

      // Get booking link from sitewide settings
      const { data: settings } = await supabase.from("sitewide_settings").select("booking_link").single()

      return {
        id: crypto.randomUUID(),
        serviceId: data.id,
        title: data.title,
        description: data.summary,
        slug: data.slug,
        bookingLink: settings?.booking_link || "#",
      }
    } catch (error) {
      console.error("Error getting service recommendation:", error)
      return null
    }
  },

  /**
   * Processes the Dialogflow response with additional data from Supabase
   */
  async processResponse(dialogflowResponse: DialogflowResponse): Promise<string> {
    const { intent, parameters, fulfillmentText } = dialogflowResponse

    // If Dialogflow already has a good response, use it as a fallback
    let enhancedResponse = fulfillmentText

    try {
      switch (intent.displayName) {
        case "Contact Information":
          const companyInfo = await this.getCompanyInfo()
          if (companyInfo) {
            enhancedResponse = `You can reach us at:\n\nPhone: ${companyInfo.phone_number}\nEmergency: ${companyInfo.emergency_phone}\nEmail: ${companyInfo.email}\n\nOur main office is located at:\n${companyInfo.address1_line}, ${companyInfo.address1_city}, ${companyInfo.address1_province}`
          }
          break

        case "Service Areas":
          const areas = await this.getServiceAreas()
          if (areas.length > 0) {
            enhancedResponse = `We proudly serve the following areas:\n\n${areas.join(", ")}`
          }
          break

        case "Business Hours":
          const settings = await this.getCompanyInfo()
          if (settings?.business_hours) {
            enhancedResponse = `Our business hours are:\n\n${settings.business_hours.replace(/,/g, "\n")}`
          }
          break

        case "Plumbing Issue":
          if (parameters.issue) {
            const issue = await this.evaluatePlumbingIssue(parameters.issue)
            if (issue) {
              if (issue.severity === "high" || issue.emergencyContact) {
                const info = await this.getCompanyInfo()
                enhancedResponse = `This sounds like an emergency situation. Please call our emergency line immediately at ${info?.emergency_phone || "our emergency number"}.`
              } else {
                const recommendation = await this.getServiceRecommendation(issue.recommendedService)
                if (recommendation) {
                  enhancedResponse = `Based on your description, you might be experiencing a ${issue.name}. We recommend our ${recommendation.title} service. Would you like to book an appointment?`
                }
              }
            }
          }
          break

        case "Service Information":
          if (parameters.service) {
            const recommendation = await this.getServiceRecommendation(parameters.service)
            if (recommendation) {
              enhancedResponse = `Our ${recommendation.title} service includes ${recommendation.description}. You can book this service online or call us for more information.`
            }
          }
          break
      }

      return enhancedResponse
    } catch (error) {
      console.error("Error processing response:", error)
      return fulfillmentText // Fallback to original response
    }
  },
}

